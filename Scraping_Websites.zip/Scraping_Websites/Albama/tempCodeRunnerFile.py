 # button.click()
    # button.clear()