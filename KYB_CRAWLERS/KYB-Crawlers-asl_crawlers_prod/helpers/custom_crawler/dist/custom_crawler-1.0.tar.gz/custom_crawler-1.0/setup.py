from setuptools import setup, find_packages
 

setup(
    name='custom_crawler',
    version='1.0',
    author='Tayyab Ali',
    author_email='tayyab.ali@enlatics.com',
    description='A custom crawlers module',
    packages=['.'
              ],
)